function saludo(nombre){
    alert("HOLA..."+nombre+"\n"+"Vamos a aprender los 5 programas fantasticos web: html - css - javascript - php - mysql");
}